#include <iostream>
#include <math.h>
using namespace std;

int main(int argc, const char * argv[])
{
	double  size;
	if (argc == 1)
	{
		cout << "��Ʈ ũ��:";
		cin >> size;
	}
	else
	{
		size = atoi(argv[1]);
	}
	for (float x = 0; x<size; x++)
	{
		for (float y = 0; y <= 4 * size; y++)
		{
			double dist1 = sqrt(pow(x - size, 2) + pow(y - size, 2));
			double dist2 = sqrt(pow(x - size, 2) + pow(y - 3 * size, 2));
			if (dist1 < size + 0.5 || dist2 < size + 0.5)
			{
				cout << "*";
			}
			else
			{
				cout << " ";
			}
		}
		cout << endl;
	}
	//�Ʒ���
	for (int i = 1; i <= 2 * size; i++)
	{
		for (int j = 0; j < i; j++)
		{
			cout << " ";
		}
		for (int j = 0; j < 4 * size + 1 - 2 * i; j++)
		{
			cout << "*";
		}
		cout << endl;
	}
	return 0;
}