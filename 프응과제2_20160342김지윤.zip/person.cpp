#include "Person.h"

Person::Person(string name, int k, int e, int m)
	{
	this->name = name;
	this->Korean_Score = k;
	this->English_Score = e;
	this->Math_Score = m;
	}
Person::Person() {};
void Person::setName(string name) { this->name = name; }
void Person::setKor(int k) { this->Korean_Score = k; }
void Person::setEng(int e) { this->English_Score = e; }
void Person::setMat(int m) { this->Math_Score = m; }
string Person::getName() { return name; }
int Person::getKor() { return Korean_Score; }
int Person::getEng() { return English_Score; }
int Person::getMat() { return Math_Score; }
void Person::Print()
{
	cout << name << " is ";
	double average = (Korean_Score+English_Score+Math_Score) / 3;
	if (average >= 90)
	{
		cout << "A (Average : ";
	}
	else if (80 <= average && average < 90)
	{
		cout << "B (Average : ";
	}
	else if (70 <= average && average < 80)
	{
		cout << "C (Average : ";
	}
	else if (60 <= average && average < 70)
	{
		cout << "D (Average : ";
	}
	else
	{
		cout << "F (Average : ";
	}
	cout << average << " )" << endl;
}
double Person::Average() 
{
	return (Korean_Score + English_Score + Math_Score) / 3;
}

//void Person::Input_Person() 
//{
//	cout << "> Input Person (Name, Korean, English, Math) ? ";
//	cin >> name >> Korean_Score >> English_Score >> Math_Score;
//}
//
//void Person::Delete_Person()
//{
//	cout << "> Input Person (Name) ? ";
//	cin >> name;
//
//}
//
//void Person::Find_Person() 
//{
//	
//}