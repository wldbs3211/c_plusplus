#include "PersonList.h"
#include "IOhandler.h"

int main() 
{

	PersonList pl;
	IOhandler p;
	int menu_num;
	while (1)
	{
		p.printmenu();
		cin >> menu_num;
		switch (menu_num)
		{
		case 1: pl.Input_Person(); break;
		case 2: pl.Delete_Person(); break;
		case 3: pl.Find_Person(); break;
		case 4: pl.Print_All(); break;
		case 5: pl.Print_Max(); break;
		case 6: pl.Print_Min(); break;
		case 7: return 1;
		default: cout << "Please Check the Menu_Number." << endl;	break;
		}
	}
	return 0;

}


// ����ó�� -> ���� 0�� ~ 100��
// delete ���� �� ����