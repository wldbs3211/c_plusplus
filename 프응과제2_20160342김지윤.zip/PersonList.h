#pragma once
#include "Person.h"

class PersonList 
{
private :
	Person p_list[10];
	int count;
public :
	PersonList();
	void Input_Person();
	void Delete_Person();
	void Find_Person();
	void Print_All();
	void Print_Max();
	void Print_Min();
};