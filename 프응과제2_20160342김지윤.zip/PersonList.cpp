#include "PersonList.h"
#include <cstring>

PersonList::PersonList() { count = 0; }
void PersonList::Input_Person()
{
	cout << "> Input Person (Name, Korean, English, Math) ? ";
	string n;
	string k,e,m;
	int kor = 0;
	int eng = 0;
	int mat = 0;
	cin.ignore();
	getline(cin, n,',');
	n = n.substr(0, n.find(',')-1);
	getline(cin, k, ',');
	getline(cin, e, ',');
	cin >> m;
	kor = stoi(k);
	eng = stoi(e);
	mat = stoi(m);
		p_list[count].setName(n);
		p_list[count].setKor(kor);
		p_list[count].setEng(eng);
		p_list[count].setMat(mat);
		count++;
}
void PersonList::Delete_Person()
{
	cin.ignore();
	cout << "> Input Person (Name) ? ";
	string n;
	getline(cin, n);
	for (int i = 0; i < count; i++)
	{
		if (p_list[i].getName() == n)
		{
			p_list[i] = p_list[count - 1];//���� ���� �׸��� i��°�� ���
			count--;
		}
		else if (p_list[i].getName() != n && i == count)
		{
			cout << "Please Check the Name." << endl;
		}
	}
}
void PersonList::Find_Person() 
{
	cin.ignore();
	cout << "> Input Person (Name) ? ";
	string n;
	getline(cin, n);
	for (int i = 0; i < count; i++)
	{
		if (p_list[i].getName().find(n) != -1)
		{
			p_list[i].Print();
		}
	}
}
void PersonList::Print_All() 
{
	for (int i = 0; i < count; i++)
	{
		p_list[i].Print();
	}
}
void PersonList::Print_Max() 
{
	double max_index=0;
	int max = 0;
	for (int i = 0; i < count; i++)
	{
		if (p_list[i].Average() > max_index)
		{
			max_index = p_list[i].Average();
			max = i;
		}
	}
	p_list[max].Print();
}
void PersonList::Print_Min() 
{
	double min_index = 100;
	int min = 0;
	for (int i = 0; i < count; i++)
	{
		if (p_list[i].Average() < min_index)
		{
			min_index = p_list[i].Average();
			min = i;
		}
	}
	p_list[min].Print();
}
