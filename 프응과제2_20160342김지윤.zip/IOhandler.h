#pragma once
#include <iostream>
using namespace std;

class IOhandler {

public:
	void printmenu();

};

void IOhandler::printmenu() 
{
	cout << "1. Input Person	2. Delete Person	3. FInd Person" << endl;
	cout << "4. Print All	5. Print Max	6.Print Min	7. Exit" << endl;
}