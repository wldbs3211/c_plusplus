#pragma once
#include <iostream>
#include <string>
using namespace std;

class Person {
private:
	string name;
	int Korean_Score, English_Score, Math_Score;
public:
	Person(string name, int k, int e, int m);
	Person();
	void setName(string name);
	void setKor(int k);
	void setEng(int e);
	void setMat(int m);
	string getName();
	int getKor();
	int getEng();
	int getMat();
	void Print();
	double Average();
};