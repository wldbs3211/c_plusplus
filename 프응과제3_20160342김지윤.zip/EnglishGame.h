#pragma once
#include "Dictionary.h"
#include "Question.h"
#include <ctime>
#include <time.h>
#include <vector>

class EnglishGame
{
private:
	Dictionary dictionary;
	Question *currQuestion;
	clock_t startTime;
	vector<int> usedNum; // ����ߴ� ������ȣ

	void performance();
	void UproadQuestion();
	double endTime(clock_t start);

public:
	EnglishGame();
	~EnglishGame();

	void run();
};

