#include "EnglishGame.h"

int main()
{
	EnglishGame englishGame;

	englishGame.run();

	return 0;
}