#include <iostream>
#include <string>
using namespace std;

int main()
{
	string contunual[10];
	string word[10];
	int cCount = 0;
	int length;
	int count = 0;
	
	char vowel[5] = { 'a','e','u','i','o' };

	for (int turn = 0; turn < 10; turn++)
	{
		while (1)
		{
			cout << turn + 1 << "��° �ܾ�?";
			cin >> word[turn];
			if (word[turn].length() < 20) break;
			cout << "20���� �̳��� �Է��Ͻÿ� :" << endl;
		}
		for (int i = 0; i < word[turn].length(); i++)
		{
			for (int j = 0; j < 5; j++)
			{
				if (word[turn].at(i) == vowel[j] && i != word[turn].length() - 1)
				{
					for (int k = 0; k < 5; k++)
					{
						if (word[turn].at(i + 1) == vowel[k])
						{
							count++;
							break;
						}
					}
				}
				if (count != 0) break;
			}
			if (count != 0) break;
		}
		if (count != 0)
		{
			contunual[cCount++] = word[turn];
		}
		count = 0;
	}

	cout << "������ ������ ���� �ܾ�" << endl;
	for (int i = 0; i < cCount; i++)
	{
		cout << contunual[i] << endl;
	}

}