//#include <iostream>
//using namespace std;
//
//int main()
//{
//	int size = 0;
//
//	cout << "���� �Է�:";
//	cin >> size;
//	if (size % 2 == 0)
//	{
//		cout << "���� �Է�:";
//		cin >> size;
//	}
//	for (int i = 1; i <= size / 2 + 1; i++)
//	{
//		for (int j = 0; j < size / 2 - i + 1; j++)
//		{
//			cout << " ";
//		}
//		for (int j = 0; j < 2 * i - 1; j++)
//		{
//			cout << "*";
//		}
//
//		cout << endl;
//	}
//	for (int i = 1; i <= (size - 1) / 2; i++)
//	{
//		
//		for (int j = 1; j <= i; j++)
//		{
//			cout << " ";
//		}
//		for (int j = 1; j <= size - (2 * i); j++)
//		{
//			cout << "*";
//		}
//		cout << endl;
//	}
//	return 0;
//}
