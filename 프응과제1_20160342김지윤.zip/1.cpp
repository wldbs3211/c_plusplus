//#include <iostream>
//using namespace std;
//
//int main()
//{
//	int n = 0;
//	int result = 0;
//	int temp = 1;
//	cout << "2���� �Է�?";
//	cin >> n;
//	while (n != 0)
//	{
//		if (n % 2)
//			result += temp;
//		temp *= 2;
//		n /= 10;
//
//	}
//	cout << "10���� = " << result << endl;
//	return 0;
//}