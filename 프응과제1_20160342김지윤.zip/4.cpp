//#include <iostream>
//using namespace std;
//
//int main()
//{
//	int Aarr[10];
//	int Barr[10];
//	int count = 0;
//	int cnt = 0;
//
//	cout << "���� A �Է� :";
//
//	for (int i = 0; i < 10; i++)
//	{
//		cin >> Aarr[i];
//		if (Aarr[i] == -1)
//			break;
//		count++;
//	}
//
//	cout << "���� B �Է� :";
//	for (int i = 0; i < 10; i++)
//	{
//		cin >> Barr[i];
//		if (Barr[i] == -1)
//			break;
//		cnt++;
//	}
//
//	cout << "������: < ";
//	for (int i = 0; i < count; i++)
//	{
//		cout << Aarr[i] << " ";
//	}
//	for (int i = 0; i < cnt; i++)
//	{
//		for (int j = 0; j < count; j++)
//		{
//			if (Barr[i] == Aarr[j])
//			{
//				break;
//			}
//			else if (Barr[i] != Aarr[j] && j == count - 1)
//			{
//				cout << Barr[i] << " ";
//			}
//		}
//	}
//	cout << ">" << endl;
//
//	cout << "������: < ";
//	for (int i = 0; i < count; i++)
//	{
//		for (int j = 0; j < cnt; j++)
//		{
//			if (Aarr[i] == Barr[j])
//			{
//				cout << Aarr[i] << " ";
//			}
//		}
//	}
//	cout << ">" << endl;
//
//	cout << "������: < ";
//	for (int i = 0; i < count; i++)
//	{
//		for (int j = 0; j < cnt; j++)
//		{
//			if (Aarr[i] != Barr[j] && j == cnt - 1)
//			{
//				cout << Aarr[i] << " ";
//			}
//			else if (Aarr[i] == Barr[j])
//			{
//				break;
//			}
//		}
//	}
//	cout << ">" << endl;
//}