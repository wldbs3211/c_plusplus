#pragma once
#include"student.h"
#include"filemanager.h"

class StudentList
{
private:
	int count;	
	Student *s[100];//studentŬ������ 100��
	Filemanager fm;
public:
	StudentList() 
	{
		count = 0;
		for (int i = 0; i < 100; i++)
		{
			s[i] = new Student();
		}
	};
	~StudentList() {};
	void create();
	void read();
	void update();
	void deleteStudent();
	void LoadFile();
	void SaveFile();
};