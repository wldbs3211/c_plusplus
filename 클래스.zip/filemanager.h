#pragma once
#include"student.h"
#include<fstream>

class Filemanager
{
private:
	int count;
public:
	Filemanager() { count = 0; };
	~Filemanager() {};
	void save(Student *sl[] ,int count);
	void load(Student *sl[]);

	int getCount(){ return count; }
};