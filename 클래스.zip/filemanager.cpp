#include"filemanager.h"

void Filemanager::save(Student *sl[],int count)
{
	ofstream fout;
	this->count = count;
	fout.open("test.txt");
	for (int i = 0; i < count; i++)
	{
		fout << sl[i]->getName() << " " << sl[i]->getid() << " " << sl[i]->getgrade() << endl;
	}
	fout.close();
}

void Filemanager::load(Student *sl[])
{
	ifstream fin;
	fin.open("test.txt");
	Student s;
	string name;//�̸�
	int id;//�й�
	int grade;//�г�
	
	if (fin.fail())
	{
		cout << "���Ͽ��� ���� !!" << endl;
		exit(1);
	}
	while (1)//�����̳���������
	{
		fin >> name >> id >> grade;
		if (fin.fail()) break;
		
			sl[count++] = new Student(name, id, grade);
	
		
		
	}
	fin.close();
	
}