#pragma once
#include<iostream>
using namespace std;

class Shape
{
protected:
	int centerX, centerY;
	
public:
	Shape() {};
	Shape(int centerX, int centerY) { this->centerX=centerX; this->centerY=centerY; }
	virtual void print() = 0;
	virtual double calArea() = 0;
	int getX() { return centerX; }
	int getY() { return centerY; }
	
};

class Rectangle : public Shape
{
private:
	int size;
	int height;
	int width;
public:
	Rectangle() {};
	Rectangle(int rx, int ry, int width, int height) : Shape(rx,ry)
	{
		this->width = width;
		this->height = height;
	}
	virtual void print();
	virtual double calArea();
	void resize(int width, int height);
	int getWidth() { return width; }
	int getHeight() { return height; }
};

class Circle : public Shape
{
private:
	double size;
	int radius;
public:
	Circle() {};
	Circle(int cx, int cy, int radius) : Shape(cx,cy)
	{
		this->radius = radius;
	}
	virtual void print();
	virtual double calArea();
	void resize(int radius);
	int getRadius() { return radius; }
};