#include"Shape.h"
#include <fstream>
#include <string>

const int MAX = 10;

void loadFile(Shape* b[], int& count);
void saveFile(Shape* b[], int& count);

int main()
{
	Shape *shape[MAX];
	int count = 1;
	cout << "���Ͽ��� ���������� �о�鿴���ϴ�." << endl;
	loadFile(shape, count);

	int menu;
	int num;
	int r_width, r_height, r_radius;

	while (1)
	{
		cout << endl;
		cout << "��� ���� [1) ũ������ 2) ��� 3) ����] --- ";
		cin >> menu;
		cout << endl;
		switch (menu)
		{
		case 1:

			cout << "��� ������ ��ȣ�� �����ϼ��� --- ";
			cin >> num;

			if (typeid(*shape[num]) == typeid(Rectangle))
			{
				cout << "������ �ʺ�� ���̸� ������� �Է��ϼ��� --- ";
				cin >> r_width >> r_height;

				((Rectangle*)shape[num])->resize(r_width, r_height);

			}

			else if (typeid(*shape[num]) == typeid(Circle))
			{
				cout << "������ �������� �Է��ϼ��� --- ";
				cin >> r_radius;

				((Circle*)shape[num])->resize(r_radius);

			}
			saveFile(shape, count);
			break;

		case 2:
			for (int i = 1; i < count; i++)
			{
				cout << "[" << i << "] ";
				shape[i]->calArea();
				shape[i]->print();
			}
			break;
		case 3:
			return 1;
		default:
			cout << "���� ���� �ʴ� �޴� �Դϴ�. �ٽ� �Է����ּ���" << endl;
			continue;
		}

	}


	return 0;
}

void loadFile(Shape* shape[], int& count)
{
	ifstream fin;
	cout << "���ϸ�: ";
	string name;
	cin >> name;
	fin.open(name);
	if (fin.fail())
	{
		cout << "���� ���� ����" << endl;
		exit(1);
	}
	char checkShape;
	int insertX, insertY, insertWidth, insertHight, insertRadius;

	fin >> checkShape;
	while (!fin.eof())
	{

		if (checkShape == 'R' || checkShape == 'r')
		{
			fin >> insertX >> insertY >> insertWidth >> insertHight;
			shape[count] = new Rectangle(insertX, insertY, insertWidth, insertHight);
			cout << "[" << count << "] ";
			shape[count]->calArea();
			shape[count]->print();
			count++;
		}
		else if (checkShape == 'C' || checkShape == 'c')
		{
			fin >> insertX >> insertY >> insertRadius;
			shape[count] = new Circle(insertX, insertY, insertRadius);
			cout << "[" << count << "] ";
			shape[count]->calArea();
			shape[count]->print();

			count++;
		}
		fin >> checkShape;
	}
	cout << "-------------------------------------------------------------------------------------" << endl;
	fin.close();
}

void saveFile(Shape* shape[], int& count)
{
	ofstream fout;
	fout.open("shape.txt");

	Shape *temp;

	for (int i = 1; i < count; i++) {
		for (int j = i; j < count; j++) {
			if (shape[i]->calArea() < shape[j]->calArea()) {
				temp = shape[i];
				shape[i] = shape[j];
				shape[j] = temp;
			}
		}
	}
	for (int i = 1; i < count; i++)
	{
		if (typeid(*shape[i]) == typeid(Rectangle))
		{
			fout << "R" << " " << shape[i]->getX() << " " << shape[i]->getY() << " " << ((Rectangle*)shape[i])->getWidth() << " " << ((Rectangle*)shape[i])->getHeight() << endl;
		}
		else if (typeid(*shape[i]) == typeid(Circle))
		{
			fout << "C" << " " << shape[i]->getX() << " " << shape[i]->getY() << " " << ((Circle*)shape[i])->getRadius() * 2 << endl;
		}
	}
	fout.close();
}