#pragma once
#include "Shape.h"

void Rectangle::print()
{
	cout << "�簢�� : �߽� (" << centerX << "," << centerY << ") �»�� (" << centerX+height << "," << centerY+width << ") ���ϴ� (" << centerX+height << "," << centerY+width << ") �ʺ� " << width << " ���� " << height << " ���� " << size << endl;
}

double Rectangle::calArea()
{
	size = height * width;
	return size;
}

void Rectangle::resize(int width, int height)
{
	this->width = width;
	this->height = height;
}

void Circle::print()
{
	cout << "�� : �߽� (" << centerX << "," << centerY << ") ������ " << radius << " ���� " << size << endl;
}

double Circle::calArea()
{
	int size;
	size = radius*radius*3.14;
	return size;
}

void Circle::resize(int radius)
{
	this->radius = radius;
}