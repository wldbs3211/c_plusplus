#pragma once
#include <iostream>
#include <string>
using namespace std;

class Book
{
private:
	string bookname;
	string booknumber;
	int rentnumber;
public:
	Book();
	Book(string booknumber, string bookname);
	Book(Book& temp);
	~Book() {};
	string getBooknumber() { return booknumber; }
	string getBookname() { return bookname; }
	void setRentnumber(int rentnumber);
	int getRentnumber();
};

