#include "ManageBook.h"

void ManageBook::RentBook(int number, string bookname)
{
	int sum = 0;
	int count = 0;
	int a = 0;
	int b = 0;
	int temp = 0;
	int empty = -1;
	for (int i = 0; i < 5; i++)
	{
		if (book[i].getRentnumber() == number)
			sum++;
	}
	if (sum < 2)
	{
		for (int i = 0; i < 5; i++)
		{
			if (bookname == book[i].getBookname())
			{
				count++;
				if (book[i].getRentnumber() == -1)
				{
					temp = i;
				}
				if (book[i].getRentnumber() != -1)
				{
					b++;
				}
			}
			if (bookname == book[i].getBookname() && book[i].getRentnumber() == number)
			{
				a++;
			}
		}
		for (int i = 0; i < 3; i++)
		{
			if (student[i].getNumber() == number)
				empty = i;
		}
		if (count == 0)
		{
			cout << "���� å �Դϴ�." << endl;
		}
		else if (empty == -1)
		{
			cout << "���� �л� �Դϴ�." << endl;
		}
		else if (a != 0)
		{
			cout << "�̹� ���� ���� å�Դϴ�." << endl;
		}
		else if (count == b)
		{
			cout << "������ å�� ��� ���� �� �Դϴ�." << endl;
		}
		else
		{
			book[temp].setRentnumber(number);
		}
	}
	else {
		for (int i = 0; i < 3; i++)
		{
			if (student[i].getNumber() == number)
				empty = i;
		}
		cout << number << " " << student[empty].getName() << " �� �̹� 2���� å�� ���� �� �Դϴ�. " << endl;
	}
}

void ManageBook::ReturnBook(int number , string name)
{
	int empty = 0;	//���� å ã��
	for (int i = 0; i < 5; i++)
	{
		if (book[i].getBookname() == name)
		{
			empty++;
		}
		if (book[i].getRentnumber() == number && book[i].getBookname() == name)
		{
				book[i].setRentnumber(-1);
		}
	}
	int empty1 = 0;	//���� �л� ã��
	for (int i = 0; i < 3; i++)
	{
		if (student[i].getNumber() == number)
			empty1++;
	}
	if (empty1 == 0)	cout << "���� �л� �Դϴ�." << endl;
	if (empty == 0)	cout << "���� å �Դϴ�. " << endl;
}

void ManageBook::PrintList()
{
	int t = 0;	// �й� �̸� �ѹ��� ����ϱ� ���� ����
	for (int i = 1001; i <= 1003; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			if (book[j].getRentnumber() == i && t == 0)
			{
				cout << student[i-1001].getNumber() << " " << student[i - 1001].getName() << " [ " << book[j].getBookname() << " " << book[j].getBooknumber() << " ] ";
				t++;
			}
			else if (book[j].getRentnumber() == i)
			{
				cout << " [ " << book[j].getBookname() << " " << book[j].getBooknumber() << " ] ";
			}
		}
		if (t > 0)
		{
			cout << endl;
			t = 0;
		}
	}
}
