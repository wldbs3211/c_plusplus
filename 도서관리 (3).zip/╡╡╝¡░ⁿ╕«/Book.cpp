#include "Book.h"

Book::Book()
{
	bookname = "NULL";
	booknumber = "NULL";
	rentnumber = -1;
}

Book::Book(Book& temp)
{
	this->bookname = temp.bookname;
	this->booknumber = temp.booknumber;
	rentnumber = -1;
}

Book::Book(string booknumber, string bookname)
{
	this->bookname = bookname;
	this->booknumber = booknumber;
	rentnumber = -1;
}


void Book::setRentnumber(int rentnumber)
{
	this->rentnumber = rentnumber;
}

int Book::getRentnumber()
{
	return rentnumber;
}