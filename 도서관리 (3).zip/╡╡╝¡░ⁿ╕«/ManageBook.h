#pragma once
#include "Book.h"
#include "Student.h"

class ManageBook
{
private:
	Book book[5];
	Student student[3];
public:
	ManageBook()
	{
		Book temp("B01", "C++");
		book[0] = temp;
		Book temp1("B02", "Java");
		book[1] = temp1;
		Book temp2("B03", "Java");
		book[2] = temp2;
		Book temp3("B04", "DS");
		book[3] = temp3;
		Book temp4("B05", "CA");
		book[4] = temp4;
		Student temp5("������", 1001);
		student[0] = temp5;
		Student temp6("����ȣ", 1002);
		student[1] = temp6;
		Student temp7("�̼ҷ�", 1003);
		student[2] = temp7;
	};
	~ManageBook() {};
	void RentBook(int number, string bookname);
	void ReturnBook(int number , string bookname);
	void PrintList();

};

