#pragma once
#include <iostream>
#include <string>
using namespace std;

class Student
{
private:
	string name;
	int number;

public:
	Student() 
	{
		name = "NULL";
		number = 0;
	};
	Student(string name, int number)
	{
		this->name = name;
		this->number = number;
	};
	int getNumber() { return number; }
	string getName() { return name; }
	~Student() {};
	
};

