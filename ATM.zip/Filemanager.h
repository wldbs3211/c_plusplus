#pragma once
#include <fstream>
#include "AccountList.h"

class Filemanager
{
private:
	AccountList *ac;
public:
	Filemanager(AccountList *ac);
	~Filemanager();

	void Load();
	void Save();
};

