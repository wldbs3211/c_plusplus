#pragma once
#include <iostream>

using namespace std;

class Bank
{
public:
	virtual void execute();
	Bank();
	~Bank();
};

