#pragma once
#include "Bank.h"
#include "AccountList.h"

class Deposit : public Bank
{
private:
	AccountList *ac;
public:
	virtual void execute();
	Deposit(AccountList *ac);
	~Deposit();
};

