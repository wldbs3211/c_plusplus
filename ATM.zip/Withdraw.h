#pragma once
#include "Bank.h"
#include "AccountList.h"

class Withdraw : public Bank
{
private:
	AccountList *ac;
public:
	virtual void execute();
	Withdraw(AccountList *ac);
	~Withdraw();
};

