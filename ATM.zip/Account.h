#pragma once
#include <iostream>
#include <string>

using namespace std;

class Account
{
private:
	int num;
	string name;
	int balance;
	int password;

public:
	Account();
	Account(int num, string name, int balance, int password)
	{
		this->num = num;
		this->name = name;
		this->balance = balance;
		this->password = password;
	};
	~Account() {};

	void setBalance(int balance) { this->balance = balance; }

	int getNum() { return num; }
	string getName() { return name; }
	int getBalance() { return balance; }
	int getPassword() { return password; }

};

