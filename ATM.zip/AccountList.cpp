#include "AccountList.h"

AccountList::AccountList()
{
	count = 0;
}

void AccountList::create()
{
	int num;
	string name;
	int balance;
	int password;
	cout << "���µ��" << endl;
	cout << "���¹�ȣ:";
	cin >> num;
	cout << "�̸�:";
	cin >> name;
	cout << "�ܾ�:";
	cin >> balance;
	cout << "��й�ȣ:";
	cin >> password;
	a[count] = Account(num, name, balance, password);
	count++;

}
void AccountList::load(int num, string name, int balace, int password)
{
	a[count] = Account(num, name, balace, password);
	count++;
}
void AccountList::read()
{
	cout << "������ȸ" << endl;
	for (int i = 0; i < count; i++)
	{
		cout << a[i].getNum() <<" "<< a[i].getName() <<" " << a[i].getBalance() << " " << a[i].getPassword() << endl;
	}
}



