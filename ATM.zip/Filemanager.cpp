#include "Filemanager.h"



Filemanager::Filemanager(AccountList *ac)
{
	this->ac = ac;
}


Filemanager::~Filemanager()
{
}

void Filemanager ::Load()
{
	ifstream fin;
	fin.open("test.txt");
	int num, balance, password;
	string name;
	if (fin.fail())
	{
		cout << "���� �������" << endl;
		exit(1);
	}
	while (1)
	{
		fin >> name >> num >> balance >> password;
		if (name == "END") break;
		ac->load(num, name, balance, password);
	}
}

void Filemanager::Save()
{
	ofstream fout;
	fout.open("test.txt");
	for (int i = 0; i < ac->getCount(); i++)
	{
		Account *temp = ac->getAccount(i);
		fout << temp->getName() << " " << temp->getNum() << " " << temp->getBalance() << " " << temp->getPassword() << endl;
		if (i == ac->getCount() - 1)
			fout << "END" << endl;
	}

}

