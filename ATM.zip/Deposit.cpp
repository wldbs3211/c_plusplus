#include "Deposit.h"


Deposit::Deposit(AccountList *ac)
{
	this->ac = ac;
}


Deposit::~Deposit()
{
	
}

void Deposit::execute()
{
	int num;
	int money;
	int password;

	cout << "�Ա�" << endl;
	cout << "���¹�ȣ �Է�" << endl;
	cin >> num;
	for (int i = 0; i < ac->getCount(); i++)
	{
		Account *temp = ac->getAccount(i);
		if (temp->getNum() == num)
		{
			cout << "��й�ȣ �Է�" << endl;
			cin >> password;
			if (temp->getPassword() == password)
			{
				cout << "�Ա� �ݾ� �Է�" << endl;
				cin >> money;

				temp->setBalance(temp->getBalance() + money);
			}
			else
				cout << "��й�ȣ�� ���� �ʽ��ϴ�." << endl;
		}
	}
}
