#pragma once
#include "Account.h"

class AccountList
{
private:
	int count;
	Account a[100];
public:
	AccountList();
	~AccountList() {};

	void create();
	void read();
	int getCount() { return count; }
	void load(int num, string name, int balace, int password);
	Account* getAccount(int i) { return &a[i]; }
};

