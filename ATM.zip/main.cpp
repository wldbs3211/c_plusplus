#include "Accountlist.h"
#include "Bank.h"
#include "Withdraw.h"
#include "Deposit.h"
#include "Filemanager.h"
int main()
{
	AccountList *al = new AccountList;
	Bank *bank[2];
	Filemanager f(al);
	bank[0] = new Withdraw(al) ;
	bank[1] = new Deposit(al);
	int n;
		f.Load();
	while (1)
	{
		cout << "1.���µ��" << endl;
		cout << "2.������ȸ" << endl;
		cout << "3.�Ա�" << endl;
		cout << "4.���" << endl;
		cout << "5.����" << endl;
		cin >> n;
		switch (n)
		{
		case 1:
			al->create();
			break;
		case 2:
			al->read();
			break;
		case 3:
			bank[1]->execute();
			break;
		case 4:
			bank[0]->execute();
			break;
		case 5:
			f.Save();
			return 1;
		default:
			break;
		}

	}
	return 0;
}